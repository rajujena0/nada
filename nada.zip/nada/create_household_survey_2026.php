<?php
/**
 * Script to create dummy Household Survey 2026 data in NADA
 * 
 * Access via web: http://your-site/index.php/create_household_survey_2026
 * Or run via CLI: php index.php create_household_survey_2026
 */

defined('BASEPATH') OR exit('No direct script access allowed');

class Create_household_survey_2026 extends MY_Controller {

    public function __construct() {
        parent::__construct($skip_auth = TRUE); // Skip auth for this script
        $this->load->database();
        $this->load->model('Dataset_model');
        $this->load->model('Dataset_microdata_model');
        $this->load->model('Variable_model');
        $this->load->model('Data_file_model');
    }

    public function index() {
        try {
            echo "Creating Household Survey 2026...\n\n";
            
            // Check if survey already exists
            $existing = $this->db->where('idno', 'HHS-2026-001')->get('surveys')->row();
            if ($existing) {
                echo "Survey already exists with ID: " . $existing->id . "\n";
                echo "Deleting existing survey...\n";
                $this->delete_survey($existing->id);
            }

            // Create survey data
            $survey_data = $this->prepare_survey_data();
            
            // Create the survey
            $survey_id = $this->Dataset_microdata_model->create_update_dataset('survey', null, $survey_data);
            
            echo "✓ Survey created with ID: $survey_id\n";
            
            // Generate report
            $this->generate_report($survey_id);
            
            echo "\n✅ Household Survey 2026 created successfully!\n";
            echo "Survey URL: " . site_url('catalog/' . $survey_id) . "\n";
            
        } catch (Exception $e) {
            echo "❌ Error: " . $e->getMessage() . "\n";
            echo "Stack trace: " . $e->getTraceAsString() . "\n";
        }
    }

    private function prepare_survey_data() {
        $current_time = time();
        
        return array(
            'type' => 'survey',
            'repositoryid' => 'central',
            'idno' => 'HHS-2026-001',
            'title' => 'Household Survey 2026',
            'subtitle' => 'National Household Income and Expenditure Survey',
            'abbreviation' => 'HHS-2026',
            'authoring_entity' => 'National Statistics Office',
            'nation' => 'United States',
            'year_start' => 2026,
            'year_end' => 2026,
            'published' => 1,
            'created' => $current_time,
            'changed' => $current_time,
            'created_by' => 1,
            'changed_by' => 1,
            'formid' => 6, // Microdata form
            
            // Metadata structure
            'metadata' => array(
                'study_desc' => array(
                    'title_statement' => array(
                        'idno' => 'HHS-2026-001',
                        'title' => 'Household Survey 2026',
                        'sub_title' => 'National Household Income and Expenditure Survey',
                        'alternate_title' => 'HHS 2026'
                    ),
                    'authoring_entity' => array(
                        array(
                            'name' => 'National Statistics Office',
                            'affiliation' => 'Government of United States',
                            'abbr' => 'NSO'
                        )
                    ),
                    'study_info' => array(
                        'nation' => array(
                            array('name' => 'United States', 'abbreviation' => 'USA')
                        ),
                        'abstract' => 'The Household Survey 2026 is a comprehensive national survey designed to collect detailed information on household income, expenditure patterns, demographics, and living conditions. This survey provides critical data for policy formulation, economic analysis, and social research.',
                        'subject' => array(
                            array(
                                'topic' => 'Household Income',
                                'vocabulary' => 'DDI',
                                'vocabulary_uri' => ''
                            ),
                            array(
                                'topic' => 'Household Expenditure',
                                'vocabulary' => 'DDI',
                                'vocabulary_uri' => ''
                            ),
                            array(
                                'topic' => 'Demographics',
                                'vocabulary' => 'DDI',
                                'vocabulary_uri' => ''
                            )
                        ),
                        'kind_of_data' => 'Survey data',
                        'analysis_unit' => 'Household',
                        'universe' => 'All households in the United States'
                    ),
                    'method' => array(
                        'data_collection' => array(
                            'time_method' => 'Cross-sectional',
                            'data_collector' => 'National Statistics Office',
                            'frequency' => 'One-time',
                            'sampling_procedure' => 'Multi-stage stratified random sampling',
                            'mode_of_data_collection' => 'Computer Assisted Personal Interviewing (CAPI)',
                            'collection_period' => array(
                                'start' => '2026-01-01',
                                'end' => '2026-12-31'
                            )
                        )
                    ),
                    'coverage' => array(
                        'geographic_cover' => 'United States',
                        'geographic_unit' => 'State, County, City',
                        'temporal_coverage' => array(
                            'start' => '2026-01-01',
                            'end' => '2026-12-31'
                        )
                    )
                ),
                'doc_desc' => array(
                    'description' => 'Household Survey 2026 documentation'
                )
            ),
            
            // Variables (15-20 variables for the report)
            'variables' => $this->generate_variables(),
            
            // Data files
            'data_files' => array(
                array(
                    'file_name' => 'household_survey_2026_main.csv',
                    'file_id' => 'HHS-2026-MAIN',
                    'description' => 'Main household survey data file',
                    'case_count' => 5000,
                    'var_count' => 20
                )
            )
        );
    }

    private function generate_variables() {
        return array(
            array(
                'name' => 'HHID',
                'labl' => 'Household ID',
                'qstn' => 'Unique identifier for each household',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_valrng' => null,
                'var_measure' => 'nominal'
            ),
            array(
                'name' => 'REGION',
                'labl' => 'Geographic Region',
                'qstn' => 'Region where household is located',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'character',
                'var_format' => 'character',
                'var_valrng' => null,
                'var_measure' => 'nominal',
                'var_catgry' => array(
                    array('catValu' => '1', 'labl' => 'Northeast'),
                    array('catValu' => '2', 'labl' => 'Midwest'),
                    array('catValu' => '3', 'labl' => 'South'),
                    array('catValu' => '4', 'labl' => 'West')
                )
            ),
            array(
                'name' => 'URBAN',
                'labl' => 'Urban/Rural',
                'qstn' => 'Is the household located in urban or rural area?',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'character',
                'var_format' => 'character',
                'var_measure' => 'nominal',
                'var_catgry' => array(
                    array('catValu' => '1', 'labl' => 'Urban'),
                    array('catValu' => '2', 'labl' => 'Rural')
                )
            ),
            array(
                'name' => 'HH_SIZE',
                'labl' => 'Household Size',
                'qstn' => 'Total number of persons in the household',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 1, 'max' => 20)
            ),
            array(
                'name' => 'HH_INCOME',
                'labl' => 'Total Household Income',
                'qstn' => 'Total annual household income in USD',
                'var_dcml' => 2,
                'var_intrvl' => 'continuous',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 0, 'max' => 1000000)
            ),
            array(
                'name' => 'HH_EXPEND',
                'labl' => 'Total Household Expenditure',
                'qstn' => 'Total annual household expenditure in USD',
                'var_dcml' => 2,
                'var_intrvl' => 'continuous',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 0, 'max' => 1000000)
            ),
            array(
                'name' => 'FOOD_EXP',
                'labl' => 'Food Expenditure',
                'qstn' => 'Annual expenditure on food and beverages',
                'var_dcml' => 2,
                'var_intrvl' => 'continuous',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 0, 'max' => 50000)
            ),
            array(
                'name' => 'HOUSING_EXP',
                'labl' => 'Housing Expenditure',
                'qstn' => 'Annual expenditure on housing (rent, mortgage, utilities)',
                'var_dcml' => 2,
                'var_intrvl' => 'continuous',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 0, 'max' => 100000)
            ),
            array(
                'name' => 'EDUCATION_EXP',
                'labl' => 'Education Expenditure',
                'qstn' => 'Annual expenditure on education',
                'var_dcml' => 2,
                'var_intrvl' => 'continuous',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 0, 'max' => 50000)
            ),
            array(
                'name' => 'HEALTH_EXP',
                'labl' => 'Health Expenditure',
                'qstn' => 'Annual expenditure on healthcare',
                'var_dcml' => 2,
                'var_intrvl' => 'continuous',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 0, 'max' => 50000)
            ),
            array(
                'name' => 'HH_HEAD_AGE',
                'labl' => 'Household Head Age',
                'qstn' => 'Age of the household head in years',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 18, 'max' => 100)
            ),
            array(
                'name' => 'HH_HEAD_GENDER',
                'labl' => 'Household Head Gender',
                'qstn' => 'Gender of the household head',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'character',
                'var_format' => 'character',
                'var_measure' => 'nominal',
                'var_catgry' => array(
                    array('catValu' => '1', 'labl' => 'Male'),
                    array('catValu' => '2', 'labl' => 'Female'),
                    array('catValu' => '3', 'labl' => 'Other')
                )
            ),
            array(
                'name' => 'HH_HEAD_EDU',
                'labl' => 'Household Head Education',
                'qstn' => 'Highest level of education completed by household head',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'character',
                'var_format' => 'character',
                'var_measure' => 'ordinal',
                'var_catgry' => array(
                    array('catValu' => '1', 'labl' => 'No formal education'),
                    array('catValu' => '2', 'labl' => 'Primary'),
                    array('catValu' => '3', 'labl' => 'Secondary'),
                    array('catValu' => '4', 'labl' => 'Bachelor'),
                    array('catValu' => '5', 'labl' => 'Master'),
                    array('catValu' => '6', 'labl' => 'Doctorate')
                )
            ),
            array(
                'name' => 'HH_HEAD_EMPLOY',
                'labl' => 'Household Head Employment Status',
                'qstn' => 'Employment status of household head',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'character',
                'var_format' => 'character',
                'var_measure' => 'nominal',
                'var_catgry' => array(
                    array('catValu' => '1', 'labl' => 'Employed'),
                    array('catValu' => '2', 'labl' => 'Unemployed'),
                    array('catValu' => '3', 'labl' => 'Retired'),
                    array('catValu' => '4', 'labl' => 'Student'),
                    array('catValu' => '5', 'labl' => 'Other')
                )
            ),
            array(
                'name' => 'OWNERSHIP',
                'labl' => 'Housing Ownership',
                'qstn' => 'Does the household own or rent their dwelling?',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'character',
                'var_format' => 'character',
                'var_measure' => 'nominal',
                'var_catgry' => array(
                    array('catValu' => '1', 'labl' => 'Own'),
                    array('catValu' => '2', 'labl' => 'Rent'),
                    array('catValu' => '3', 'labl' => 'Other')
                )
            ),
            array(
                'name' => 'VEHICLES',
                'labl' => 'Number of Vehicles',
                'qstn' => 'Number of vehicles owned by household',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 0, 'max' => 10)
            ),
            array(
                'name' => 'INTERNET',
                'labl' => 'Internet Access',
                'qstn' => 'Does the household have internet access?',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'character',
                'var_format' => 'character',
                'var_measure' => 'nominal',
                'var_catgry' => array(
                    array('catValu' => '1', 'labl' => 'Yes'),
                    array('catValu' => '2', 'labl' => 'No')
                )
            ),
            array(
                'name' => 'CHILDREN',
                'labl' => 'Number of Children',
                'qstn' => 'Number of children under 18 in household',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 0, 'max' => 15)
            ),
            array(
                'name' => 'ELDERLY',
                'labl' => 'Number of Elderly',
                'qstn' => 'Number of persons aged 65 and above in household',
                'var_dcml' => 0,
                'var_intrvl' => 'discrete',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 0, 'max' => 10)
            ),
            array(
                'name' => 'WEIGHT',
                'labl' => 'Sampling Weight',
                'qstn' => 'Sampling weight for statistical analysis',
                'var_dcml' => 4,
                'var_intrvl' => 'continuous',
                'var_type' => 'numeric',
                'var_format' => 'numeric',
                'var_measure' => 'ratio',
                'var_valrng' => array('min' => 0, 'max' => 10)
            )
        );
    }

    private function generate_report($survey_id) {
        echo "\nGenerating report...\n";
        
        $report = array(
            'title' => 'Household Survey 2026 - Summary Report',
            'survey_id' => $survey_id,
            'generated_date' => date('Y-m-d H:i:s'),
            'sections' => array()
        );

        // Section 1: Survey Overview
        $report['sections'][] = array(
            'title' => 'Survey Overview',
            'items' => array(
                'Survey ID: HHS-2026-001',
                'Title: Household Survey 2026',
                'Collection Period: January 1, 2026 - December 31, 2026',
                'Geographic Coverage: United States',
                'Sample Size: 5,000 households',
                'Data Collection Method: Computer Assisted Personal Interviewing (CAPI)',
                'Response Rate: 87.5%',
                'Data Quality: High - All responses validated'
            )
        );

        // Section 2: Key Findings
        $report['sections'][] = array(
            'title' => 'Key Findings',
            'items' => array(
                'Average household size: 2.8 persons',
                'Median household income: $65,000',
                'Average household expenditure: $58,500',
                'Food expenditure as % of total: 12.8%',
                'Housing expenditure as % of total: 32.5%',
                'Education expenditure as % of total: 8.2%',
                'Health expenditure as % of total: 6.5%',
                'Urban households: 78%',
                'Rural households: 22%',
                'Home ownership rate: 64%',
                'Internet access: 92%',
                'Average vehicles per household: 1.8'
            )
        );

        // Section 3: Variables Summary
        $report['sections'][] = array(
            'title' => 'Variables Summary',
            'items' => array(
                'Total Variables: 20',
                'Numeric Variables: 12',
                'Categorical Variables: 8',
                'Key Variables: Household ID, Region, Income, Expenditure, Demographics',
                'All variables include complete metadata and documentation'
            )
        );

        // Section 4: Data Quality
        $report['sections'][] = array(
            'title' => 'Data Quality Indicators',
            'items' => array(
                'Completeness: 98.5%',
                'Consistency: 99.2%',
                'Accuracy: Validated through multiple checks',
                'Timeliness: Data collected within survey period',
                'Relevance: All variables align with survey objectives'
            )
        );

        // Save report to file
        $report_file = FCPATH . 'reports/household_survey_2026_report.json';
        $report_dir = dirname($report_file);
        
        if (!is_dir($report_dir)) {
            mkdir($report_dir, 0755, true);
        }
        
        file_put_contents($report_file, json_encode($report, JSON_PRETTY_PRINT));
        echo "✓ Report saved to: $report_file\n";
        
        // Also create HTML report
        $this->generate_html_report($report, $survey_id);
        
        return $report;
    }

    private function generate_html_report($report_data, $survey_id) {
        $html = '<!DOCTYPE html>
<html>
<head>
    <title>' . htmlspecialchars($report_data['title']) . '</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        h2 { color: #34495e; margin-top: 30px; border-left: 4px solid #3498db; padding-left: 15px; }
        .section { margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 5px; }
        .item { margin: 8px 0; padding: 8px; background: white; border-left: 3px solid #3498db; }
        .meta { color: #7f8c8d; font-size: 0.9em; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #3498db; color: white; }
    </style>
</head>
<body>
    <h1>' . htmlspecialchars($report_data['title']) . '</h1>
    <div class="meta">
        <strong>Generated:</strong> ' . htmlspecialchars($report_data['generated_date']) . '<br>
        <strong>Survey ID:</strong> ' . htmlspecialchars($report_data['survey_id']) . '<br>
        <strong>Survey URL:</strong> <a href="' . site_url('catalog/' . $survey_id) . '">View Survey</a>
    </div>';

        foreach ($report_data['sections'] as $section) {
            $html .= '<div class="section">';
            $html .= '<h2>' . htmlspecialchars($section['title']) . '</h2>';
            $html .= '<ul>';
            foreach ($section['items'] as $item) {
                $html .= '<li class="item">' . htmlspecialchars($item) . '</li>';
            }
            $html .= '</ul>';
            $html .= '</div>';
        }

        $html .= '</body></html>';

        $html_file = FCPATH . 'reports/household_survey_2026_report.html';
        file_put_contents($html_file, $html);
        echo "✓ HTML report saved to: $html_file\n";
    }

    private function delete_survey($survey_id) {
        // Delete variables
        $this->db->where('sid', $survey_id)->delete('variables');
        
        // Delete data files
        $this->db->where('sid', $survey_id)->delete('data_files');
        
        // Delete survey
        $this->db->where('id', $survey_id)->delete('surveys');
    }
}

