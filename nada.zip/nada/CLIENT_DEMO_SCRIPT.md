# Client Demonstration Script
## CAPI to NADA Integration - Live Demo Guide

---

## Pre-Demo Setup Checklist

- [ ] Survey ID 31 exists in NADA
- [ ] Database verification passed (run `php index.php check_db_survey_31`)
- [ ] PDF documentation generated
- [ ] All resources uploaded
- [ ] Public catalog accessible

---

## Demo Script (30 minutes)

### Part 1: The Problem (2 minutes)

**Say:**
> "You collect data in your CAPI survey solution. You have 45 enumerators visiting 55 households. You collect 21 variables with questions and categories. Now you need to archive this data in NADA and make it publicly available. How do you do this?"

**Show:**
- CAPI system with survey data
- Export files (JSON, CSV, PDFs)

**Key Point:** "We need to transfer everything from CAPI to NADA without losing any information."

---

### Part 2: The Solution - Integration Flow (5 minutes)

**Say:**
> "Let me show you how the integration works. Everything you have in CAPI automatically flows into NADA."

**Show:**
1. **CAPI Export:**
   - Survey metadata JSON
   - Variables JSON (with questions and categories)
   - Data CSV file
   - Questionnaire PDF
   - Manual PDF

2. **NADA Import:**
   - Run import script (or show API call)
   - Show database being populated
   - Show files being uploaded

**Key Point:** "One export from CAPI, one import to NADA - that's it!"

---

### Part 3: Database Verification (5 minutes)

**Say:**
> "Let me verify that everything was imported correctly. We'll check every table in the database."

**Run:**
```bash
php index.php check_db_survey_31
```

**Show Results:**
- ✅ Survey: Household Survey 2026
- ✅ Nation: India
- ✅ Variables: 21 (all with questions)
- ✅ Resources: 4 (microdata, questionnaire, manuals)
- ✅ Country: India (all tables)
- ✅ All checks passed

**Key Point:** "Every piece of data is verified. Questions, categories, country - everything is correct."

---

### Part 4: Data Display in NADA (10 minutes)

**Say:**
> "Now let's see how your data appears in NADA's public catalog. Everything from CAPI is displayed."

#### 4.1 Study Description Page
**Navigate:** `/catalog/31/study-description`

**Show:**
- Survey title: "Household Survey 2026"
- Country: **India** (not USA!)
- Abstract mentions "across India"
- Methodology: "Computer Assisted Personal Interviewing (CAPI)"
- Sample size: 55 households
- 45 enumerators

**Say:** "Notice the country is India, not United States. All metadata from CAPI is preserved."

#### 4.2 Variables List
**Navigate:** `/catalog/31/variables`

**Show:**
- Table with all 21 variables
- **Question column is populated!**
- Every variable has its question text

**Say:** "See? All the questions from CAPI are here. No data loss."

#### 4.3 Variable Detail Page
**Navigate:** Click on "URBAN" variable

**Show:**
- Variable name and label
- **Question text displayed:** "Is the household located in urban or rural area?"
- **Categories table:**
  - Value: 1, Category: Urban
  - Value: 2, Category: Rural

**Say:** "Look at this - the question is here, and the category values (1, 2) are shown. Everything from CAPI is preserved."

#### 4.4 Microdata Access
**Navigate:** `/catalog/31/get-microdata`

**Show:**
- CSV file available for download
- Variable documentation
- Data access type: Public use files

**Say:** "The data file from CAPI is available for download. Users can get the complete dataset."

#### 4.5 Resources
**Navigate:** Resources section

**Show:**
- Questionnaire PDF (from CAPI)
- Enumerator manual
- Sampling methodology report
- All downloadable

**Say:** "All your supporting documents from CAPI are here. Users can download everything."

#### 4.6 PDF Documentation
**Navigate:** Download PDF documentation

**Show PDF:**
- Open PDF
- Scroll to variables table
- **Show questions are populated**
- Scroll to category tables
- **Show category values (1, 2, 3, etc.) are displayed**
- Scroll to footer
- **Show "India - Household Survey 2026"**

**Say:** "This is the complete DDI documentation. Notice:
- All questions are here
- Category values are shown (1, 2, 3, etc.)
- Country is India
Everything from CAPI is in this PDF."

---

### Part 5: Technical Deep Dive (5 minutes)

**Say:**
> "Let me show you the technical details so you understand how robust this integration is."

#### 5.1 Database Structure
**Show:**
- `surveys` table - Survey metadata
- `variables` table - All 21 variables with questions
- `resources` table - All 4 resources
- `survey_countries` table - India linked
- `survey_repos` table - Repository linked

**Say:** "Every table is properly populated. The database structure ensures data integrity."

#### 5.2 Variable Metadata
**Run:**
```bash
php index.php verify_metadata_31
```

**Show:**
- Variable: INTERNET
- qstn field: "Does the household have internet access?"
- var_qstn_qstnlit: "Does the household have internet access?"
- Categories:
  - Value: 1, Label: Yes
  - Value: 2, Label: No

**Say:** "See how the question is stored in two places - the `qstn` field for the PDF table, and `var_qstn_qstnlit` in metadata for detailed views. Categories have both values and labels."

#### 5.3 Integration Code
**Show:** `Create_household_survey_2026.php`

**Explain:**
- This script automates the entire import
- It creates the survey
- Imports all variables
- Registers all resources
- Generates documentation

**Say:** "This is the integration script. You can customize it for your CAPI export format, or we can build an API endpoint."

---

### Part 6: Key Benefits Summary (3 minutes)

**Say:**
> "Let me summarize what this integration gives you."

**Show on screen:**

1. **Complete Data Preservation**
   - ✅ All questions from CAPI
   - ✅ All category values
   - ✅ All metadata
   - ✅ Country information

2. **Automated Workflow**
   - ✅ Export from CAPI
   - ✅ Import to NADA
   - ✅ Automatic documentation
   - ✅ No manual entry

3. **Public-Ready Output**
   - ✅ DDI-compliant
   - ✅ PDF documentation
   - ✅ Microdata access
   - ✅ Resource downloads

4. **Multi-Country Support**
   - ✅ Easy country switching
   - ✅ Localized metadata
   - ✅ Country-specific resources

**Say:** "With this integration, you can:
- Collect data in CAPI
- Archive in NADA automatically
- Make it publicly available
- All with one workflow"

---

## Q&A Preparation

### Common Questions

**Q: "Can we customize the import process?"**
**A:** "Yes, absolutely. The import script is fully customizable. You can modify it to match your CAPI export format exactly, or we can build a REST API endpoint for real-time integration."

**Q: "What if we have more variables or different structure?"**
**A:** "The system is flexible. The script handles any number of variables, any category structure. We just need to map your CAPI export format to NADA's structure."

**Q: "How do we handle updates to existing surveys?"**
**A:** "The system supports updates. You can re-import with new data, and it will update the existing survey while preserving the structure."

**Q: "Can we integrate via API instead of scripts?"**
**A:** "Yes, NADA has REST API capabilities. We can build endpoints that accept your CAPI exports directly, enabling real-time or scheduled synchronization."

**Q: "What about data validation?"**
**A:** "The import process validates all data against JSON schemas. Invalid data is rejected with clear error messages. This ensures data quality."

**Q: "How do we handle multiple countries?"**
**A:** "The system supports multiple countries. Each survey can have its country set independently. The country information flows from CAPI to NADA automatically."

---

## Closing Statement

**Say:**
> "As you can see, the integration between CAPI and NADA is complete and seamless. Everything you collect in CAPI - questions, categories, data, documents - automatically appears in NADA with full documentation. You can confidently use CAPI for data collection and NADA for data archiving, knowing that the integration handles everything automatically."

**Show:**
- Database verification (all checks passed)
- Public catalog (all data displayed)
- PDF documentation (complete with questions and values)

**Final Point:**
> "This is not a prototype. This is a working integration with real data. Survey ID 31 demonstrates everything - 55 households, 21 variables, complete documentation, all from CAPI to NADA. You can do this with any survey."

---

## Post-Demo Actions

1. Provide integration guide document
2. Share code examples
3. Schedule technical discussion
4. Discuss customization requirements
5. Plan API integration (if needed)

---

**Demo Duration:** 30 minutes  
**Key Message:** "CAPI and NADA work seamlessly together - complete automation, no data loss, public-ready output."

